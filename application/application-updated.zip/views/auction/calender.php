

    <!-- Featured Car start -->
    <section class="featured-area" style="padding-bottom:  0px;">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3">
            <div class="section-title slash-double">
              <h3>Auction Sales Calendar for April, 2018</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
        <!-- Car Details start -->
    <section class="car-details-area" style="padding: 0px 0px 0px 0px;">
      <div class="container">
        <div class="row">
            <div class="calander-mon"><i class="fa fa-angle-left"></i><span>APRIL, 2018</span><i class="fa fa-angle-right"></i></div>
            <div id="calendar"></div>
            <table class="calander-auc" style="display: none;">
              <tr>
                <th style="border-left: 1px solid #1f69b8;">SUNDAY</th>
                <th>MONDAY</th>
                <th>TUESDAY</th>
                <th>WEDNESDAY</th>
                <th>THURSDAY</th>
                <th>FRIDAY</th>
                <th style="border-right: 1px solid #1f69b8;">SATURDAY</th>
              </tr>
              <tr>
                <td></td>
                <td></td>
                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
                <td>5</td>
              </tr>
              <tr>
                <td>6</td>
                <td>7</td>
                <td>8</td>
                <td>9</td>
                <td>10</td>
                <td>11</td>
                <td>12</td>
              </tr>
              <tr>
                <td>13</td>
                <td>14</td>
                <td>15</td>
                <td>16</td>
                <td class="selected">17</td>
                <td>18</td>
                <td>19</td>
              </tr>
              <tr>
                <td>20</td>
                <td>21</td>
                <td>22</td>
                <td>23</td>
                <td>24</td>
                <td>25</td>
                <td>26</td>
              </tr>
              <tr>
                <td>27</td>
                <td>28</td>
                <td>29</td>
                <td>30</td>
                <td>31</td>
                <td></td>
                <td></td>
              </tr>
            </table>
            <div class="info-cal">Trades are not held on Saturday and Sunday</div>
        </div>
      </div>
    </section>

    