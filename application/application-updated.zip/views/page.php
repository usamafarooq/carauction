<?php 
echo $page['Content'];
?>