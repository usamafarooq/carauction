<?php
		    class Packages_model extends MY_Model{

		    	}