<?php
		    class Vehicle_type_model extends MY_Model{

		    	}