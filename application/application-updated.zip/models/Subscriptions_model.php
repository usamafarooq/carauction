<?php
		    class Subscriptions_model extends MY_Model{

		    	}