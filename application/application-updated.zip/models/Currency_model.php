<?php
		    class Currency_model extends MY_Model{

		    	}