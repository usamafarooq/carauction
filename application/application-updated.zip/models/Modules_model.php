<?php 

class Modules_model extends MY_Model
{
	
}