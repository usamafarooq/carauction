<?php
class Api_model extends MY_Model{

}