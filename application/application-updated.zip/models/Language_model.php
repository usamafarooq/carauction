<?php
		    class Language_model extends MY_Model{

		    	}