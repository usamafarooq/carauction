<?php
		    class Makes_model extends MY_Model{

		    	}