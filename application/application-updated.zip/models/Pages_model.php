<?php
		    class Pages_model extends MY_Model{

		    	}